
Simple Button matrix
""""""""""""""""""""""

.. lv_example:: widgets/btnmatrix/lv_example_btnmatrix_1
  :language: c


Custom buttons
""""""""""""""""""""""

.. lv_example:: widgets/btnmatrix/lv_example_btnmatrix_2
  :language: c


Pagination
""""""""""""""""""""""

.. lv_example:: widgets/btnmatrix/lv_example_btnmatrix_3
  :language: c


