
A button with a label and react on click event
"""""""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: get_started/lv_example_get_started_1
  :language: c

Create styles from scratch for buttons
"""""""""""""""""""""""""""""""""""""""
.. lv_example:: get_started/lv_example_get_started_2
  :language: c

Create a slider and write its value on a label
"""""""""""""""""""""""""""""""""""""""""""""""
.. lv_example:: get_started/lv_example_get_started_3
  :language: c


