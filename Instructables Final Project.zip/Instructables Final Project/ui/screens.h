#ifndef EEZ_LVGL_UI_SCREENS_H
#define EEZ_LVGL_UI_SCREENS_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _objects_t {
    lv_obj_t *main;
    lv_obj_t *music;
    lv_obj_t *go_to_main_btn;
    lv_obj_t *music_pg_btn;
    lv_obj_t *pikachu_background;
    lv_obj_t *play_pause_btn;
    lv_obj_t *time_label;
    lv_obj_t *vol_dn_btn;
    lv_obj_t *vol_up_btn;
} objects_t;

extern objects_t objects;

enum ScreensEnum {
    SCREEN_ID_MAIN = 1,
    SCREEN_ID_MUSIC = 2,
};

void create_screen_main();
void tick_screen_main();

void create_screen_music();
void tick_screen_music();

void create_screens();
void tick_screen(int screen_index);


#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_SCREENS_H*/