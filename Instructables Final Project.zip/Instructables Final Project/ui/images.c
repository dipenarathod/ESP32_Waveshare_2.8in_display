#include "images.h"

const ext_img_desc_t images[9] = {
    { "Frame0", &img_frame0 },
    { "Frame1", &img_frame1 },
    { "Frame2", &img_frame2 },
    { "Frame3", &img_frame3 },
    { "Frame4", &img_frame4 },
    { "Frame5", &img_frame5 },
    { "Frame6", &img_frame6 },
    { "Frame7", &img_frame7 },
    { "Cloud", &img_cloud },
};
