#include "actions.h"
#include "ui.h"

void action_go_to_music_pg(lv_event_t * e){
    loadScreen(SCREEN_ID_MUSIC);
}

void action_go_to_main_pg(lv_event_t * e){
    loadScreen(SCREEN_ID_MAIN);
}